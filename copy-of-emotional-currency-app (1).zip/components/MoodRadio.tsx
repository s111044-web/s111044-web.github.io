import React, { useState, useCallback, useEffect, useRef } from 'react';
import { Emotion } from '../types';
import * as geminiService from '../services/geminiService';
import { PlayIcon, StopIcon } from './Icons';

interface MoodRadioProps {
  lastEmotion: Emotion;
}

// Audio decoding utilities
function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length;
  const buffer = ctx.createBuffer(1, frameCount, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < frameCount; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
}


const MoodRadio: React.FC<MoodRadioProps> = ({ lastEmotion }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
     return () => {
        if(sourceNodeRef.current) {
            sourceNodeRef.current.stop();
        }
        if(audioContextRef.current && audioContextRef.current.state !== 'closed') {
            audioContextRef.current.close();
        }
     }
  }, []);

  const getPromptForEmotion = (emotion: Emotion): string => {
    switch (emotion) {
      case '正向':
        return '說一些開朗和鼓勵的話來慶祝美好的一天。請控制在30個字以內。';
      case '負向':
        return '對正在經歷困難時期的人說一些冷靜、溫柔和支持的話。請控制在30個字以內。';
      case '中性':
      default:
        return '說一句簡短、愉快且中性的勵志名言。請控制在30個字以內。';
    }
  };

  const playAffirmation = useCallback(async () => {
    if (isPlaying) {
        if(sourceNodeRef.current) sourceNodeRef.current.stop();
        setIsPlaying(false);
        return;
    }

    setIsLoading(true);
    const prompt = getPromptForEmotion(lastEmotion);
    const audioData = await geminiService.generateSpeech(prompt);
    setIsLoading(false);

    if (audioData) {
        try {
            if (!audioContextRef.current || audioContextRef.current.state === 'closed') {
                audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            }
            const audioContext = audioContextRef.current;
            const decodedData = decode(audioData);
            const audioBuffer = await decodeAudioData(decodedData, audioContext);

            if(sourceNodeRef.current) {
                sourceNodeRef.current.stop();
            }

            const source = audioContext.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(audioContext.destination);
            source.onended = () => {
                setIsPlaying(false);
            };
            source.start();
            sourceNodeRef.current = source;
            setIsPlaying(true);
        } catch (error) {
            console.error("Error playing audio:", error);
            setIsPlaying(false);
        }
    }
  }, [lastEmotion, isPlaying]);

  return (
    <div className="max-w-3xl mx-auto text-center">
        <h2 className="text-3xl font-bold text-cyan-500 mb-6">心情電台</h2>
        <p className="text-slate-600 mb-10">需要一點鼓勵嗎？按下播放，聽一聽為你當下心情量身打造的訊息。</p>
        <div className="flex justify-center items-center">
            <button
                onClick={playAffirmation}
                disabled={isLoading}
                className="w-40 h-40 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg transform hover:scale-105 transition-transform duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
            >
                {isLoading ? (
                    <div className="w-16 h-16 border-4 border-t-transparent border-white rounded-full animate-spin"></div>
                ) : isPlaying ? (
                    <StopIcon />
                ) : (
                    <PlayIcon />
                )}
            </button>
        </div>
        <p className="mt-8 text-slate-500">目前心情基礎：<span className="font-semibold text-slate-700">{lastEmotion}</span></p>
    </div>
  );
};

export default MoodRadio;