import React, { useState } from 'react';
import { FeedbackAnalysis } from '../types';
import * as geminiService from '../services/geminiService';
import { CloseIcon, StarIcon } from './Icons';

interface FeedbackModalProps {
  onClose: () => void;
}

const emotionStyles = {
    '正向': { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-200' },
    '負向': { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200' },
    '中性': { bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-200' },
};

const FeedbackModal: React.FC<FeedbackModalProps> = ({ onClose }) => {
    const [rating, setRating] = useState(0);
    const [hoverRating, setHoverRating] = useState(0);
    const [comment, setComment] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [analysis, setAnalysis] = useState<FeedbackAnalysis | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (isLoading || (rating === 0 && !comment.trim())) return;

        setIsLoading(true);
        try {
            const result = await geminiService.analyzeFeedback(rating, comment);
            setAnalysis(result);
        } catch (error) {
            console.error("Error analyzing feedback:", error);
            // You could show an error message to the user here
        } finally {
            setIsLoading(false);
        }
    };
    
    const handleReset = () => {
        setRating(0);
        setHoverRating(0);
        setComment('');
        setAnalysis(null);
    }

    return (
        <div className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={onClose}>
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md border border-slate-200" onClick={e => e.stopPropagation()}>
                <div className="p-6 relative">
                    <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 transition-colors">
                        <CloseIcon />
                    </button>
                    
                    {!analysis ? (
                        <>
                            <h2 className="text-2xl font-bold text-cyan-500 mb-4">提供回饋</h2>
                            <form onSubmit={handleSubmit}>
                                <div className="mb-6">
                                    <label className="block text-slate-600 mb-2">你有多滿意？</label>
                                    <div className="flex space-x-1">
                                        {[1, 2, 3, 4, 5].map((star) => (
                                            <StarIcon
                                                key={star}
                                                className={`w-8 h-8 cursor-pointer transition-colors ${
                                                    (hoverRating || rating) >= star ? 'text-yellow-400' : 'text-slate-300'
                                                }`}
                                                onMouseEnter={() => setHoverRating(star)}
                                                onMouseLeave={() => setHoverRating(0)}
                                                onClick={() => setRating(star)}
                                            />
                                        ))}
                                    </div>
                                </div>
                                <div className="mb-6">
                                     <label htmlFor="comment" className="block text-slate-600 mb-2">你的意見</label>
                                     <textarea
                                        id="comment"
                                        value={comment}
                                        onChange={(e) => setComment(e.target.value)}
                                        placeholder="告訴我們你的想法..."
                                        className="w-full h-32 bg-slate-100 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition-shadow border border-slate-200"
                                     />
                                </div>
                                <button type="submit" disabled={isLoading} className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white font-bold py-3 rounded-lg transition-colors">
                                    {isLoading ? '分析中...' : '送出回饋'}
                                </button>
                            </form>
                        </>
                    ) : (
                         <>
                            <h2 className="text-2xl font-bold text-cyan-500 mb-4">回饋分析完成</h2>
                            <div className="space-y-4 text-slate-700">
                                <div className={`${emotionStyles[analysis.sentiment].bg} p-4 rounded-lg border ${emotionStyles[analysis.sentiment].border}`}>
                                    <h3 className="font-semibold text-slate-800 mb-1">摘要</h3>
                                    <p>{analysis.summary}</p>
                                </div>
                                <div>
                                    <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-slate-200 text-slate-700 mr-2">
                                        分類: {analysis.category}
                                    </span>
                                     <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium ${emotionStyles[analysis.sentiment].bg} ${emotionStyles[analysis.sentiment].text}`}>
                                        情緒: {analysis.sentiment}
                                    </span>
                                </div>
                                <p className="text-xs text-slate-500 pt-2">感謝您的寶貴意見！這份由 AI 產生的分析將幫助我們更快地理解並處理您的回饋。</p>
                            </div>
                             <button onClick={handleReset} className="mt-6 w-full bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-3 rounded-lg transition-colors">
                                提供另一則回饋
                            </button>
                         </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default FeedbackModal;