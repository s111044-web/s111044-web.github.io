
import React from 'react';
import { CloseIcon } from './Icons';

interface AvatarSelectionModalProps {
  onClose: () => void;
  onSelect: (avatarUrl: string) => void;
}

const avatarSeeds = [
  'Midnight', 'Angel', 'Leo', 'Max', 'Zoe', 'Cleo', 'Misty', 
  'Rocky', 'Coco', 'Shadow', 'Gizmo', 'Loki'
];

const avatars = avatarSeeds.map(seed => ({
    seed,
    url: `https://api.dicebear.com/7.x/adventurer/svg?seed=${seed}`
}));

const AvatarSelectionModal: React.FC<AvatarSelectionModalProps> = ({ onClose, onSelect }) => {
  return (
    <div 
      className="fixed inset-0 bg-black/30 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl w-full max-w-lg border border-slate-200 transform animate-scale-up"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-6 relative">
          <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 transition-colors">
            <CloseIcon />
          </button>
          
          <h2 className="text-2xl font-bold text-cyan-500 mb-6 text-center">選擇你的頭像</h2>
          
          <div className="grid grid-cols-4 gap-4">
            {avatars.map(avatar => (
              <button 
                key={avatar.seed} 
                onClick={() => onSelect(avatar.url)}
                className="rounded-full aspect-square p-1 ring-2 ring-transparent hover:ring-cyan-400 transition-all duration-300 focus:outline-none focus:ring-cyan-400"
              >
                <img 
                  src={avatar.url} 
                  alt={avatar.seed} 
                  className="w-full h-full rounded-full object-cover" 
                />
              </button>
            ))}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes scale-up {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
        }
        .animate-scale-up {
            animation: scale-up 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default AvatarSelectionModal;