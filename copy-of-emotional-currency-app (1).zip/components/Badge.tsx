import React from 'react';
import { Achievement } from '../types';
import { BronzeBadgeIcon, SilverBadgeIcon, GoldBadgeIcon, PlatinumBadgeIcon, DiamondBadgeIcon } from './Icons';

interface BadgeProps {
  achievement: Achievement;
}

const badgeMap: Record<Achievement['level'], React.FC<{ className?: string }>> = {
  BRONZE: BronzeBadgeIcon,
  SILVER: SilverBadgeIcon,
  GOLD: GoldBadgeIcon,
  PLATINUM: PlatinumBadgeIcon,
  DIAMOND: DiamondBadgeIcon,
};

const Badge: React.FC<BadgeProps> = ({ achievement }) => {
  const Icon = badgeMap[achievement.level];
  return (
    <div className="relative group cursor-pointer">
      <Icon className="w-5 h-5" />
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-max px-3 py-1.5 bg-slate-800 text-white text-xs font-semibold rounded-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-20">
        {achievement.name}
        <div className="absolute left-1/2 -translate-x-1/2 top-full w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-slate-800"></div>
      </div>
    </div>
  );
};

export default Badge;