import React, { useState, useRef, useCallback, useEffect } from 'react';
import { LiveServerMessage, LiveSession } from '@google/genai';
import * as geminiService from '../services/geminiService';
import { MicOnIcon, MicOffIcon, StopIcon } from './Icons';

type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'error';

// Helper functions for audio processing
function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length;
  // Gemini Live returns mono audio at 24000 Hz sample rate
  const buffer = ctx.createBuffer(1, frameCount, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < frameCount; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
}


const LiveAgent: React.FC = () => {
  const [connectionState, setConnectionState] = useState<ConnectionState>('disconnected');
  const [transcripts, setTranscripts] = useState<{ speaker: 'user' | 'model'; text: string }[]>([]);

  const sessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);

  const currentInputTranscriptionRef = useRef('');
  const currentOutputTranscriptionRef = useRef('');

  // For audio playback queue
  const nextStartTimeRef = useRef(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const onMessage = useCallback(async (message: LiveServerMessage) => {
    // Handle transcriptions
    if (message.serverContent?.outputTranscription) {
      currentOutputTranscriptionRef.current += message.serverContent.outputTranscription.text;
    }
    if (message.serverContent?.inputTranscription) {
      currentInputTranscriptionRef.current += message.serverContent.inputTranscription.text;
    }

    if (message.serverContent?.turnComplete) {
      const fullInput = currentInputTranscriptionRef.current.trim();
      const fullOutput = currentOutputTranscriptionRef.current.trim();
      
      setTranscripts(prev => {
        const newTranscripts = [...prev];
        if (fullInput) newTranscripts.push({ speaker: 'user', text: fullInput });
        if (fullOutput) newTranscripts.push({ speaker: 'model', text: fullOutput });
        return newTranscripts;
      });
      
      currentInputTranscriptionRef.current = '';
      currentOutputTranscriptionRef.current = '';
    }

    // Handle audio playback
    const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
    if (base64Audio && outputAudioContextRef.current) {
        const outputAudioContext = outputAudioContextRef.current;
        nextStartTimeRef.current = Math.max(
            nextStartTimeRef.current,
            outputAudioContext.currentTime,
        );
        
        const audioBuffer = await decodeAudioData(
            decode(base64Audio),
            outputAudioContext,
        );
        
        const source = outputAudioContext.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(outputAudioContext.destination);
        
        source.addEventListener('ended', () => {
            audioSourcesRef.current.delete(source);
        });

        source.start(nextStartTimeRef.current);
        nextStartTimeRef.current += audioBuffer.duration;
        audioSourcesRef.current.add(source);
    }

    // Handle interruptions
    if (message.serverContent?.interrupted) {
        for (const source of audioSourcesRef.current.values()) {
            source.stop();
            audioSourcesRef.current.delete(source);
        }
        nextStartTimeRef.current = 0;
    }
  }, []);
  
  const startConversation = async () => {
    setConnectionState('connecting');
    setTranscripts([]);
    
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      sessionPromiseRef.current = geminiService.connectLive({
        onopen: () => {
          setConnectionState('connected');
          mediaStreamSourceRef.current = inputAudioContextRef.current!.createMediaStreamSource(stream);
          scriptProcessorRef.current = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
          
          scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
            }
            const pcmBlob = { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' };

            if(sessionPromiseRef.current) {
                sessionPromiseRef.current.then((session) => {
                    session.sendRealtimeInput({ media: pcmBlob });
                });
            }
          };

          mediaStreamSourceRef.current.connect(scriptProcessorRef.current);
          scriptProcessorRef.current.connect(inputAudioContextRef.current!.destination);
        },
        onmessage: onMessage,
        onerror: (e: ErrorEvent) => {
            console.error('Live session error:', e);
            setConnectionState('error');
            stopConversation();
        },
        onclose: (e: CloseEvent) => {
            stopConversation();
        },
      });

      await sessionPromiseRef.current;
    } catch (err) {
      console.error('Failed to start conversation:', err);
      setConnectionState('error');
    }
  };

  const stopConversation = useCallback(() => {
    // Stop all playing audio
    for (const source of audioSourcesRef.current.values()) {
        source.stop();
    }
    audioSourcesRef.current.clear();
    nextStartTimeRef.current = 0;

    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(session => session.close());
      sessionPromiseRef.current = null;
    }
    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current = null;
    }
    if (mediaStreamSourceRef.current) {
      mediaStreamSourceRef.current.disconnect();
      mediaStreamSourceRef.current.mediaStream.getTracks().forEach(track => track.stop());
      mediaStreamSourceRef.current = null;
    }
    if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
      inputAudioContextRef.current.close();
      inputAudioContextRef.current = null;
    }
    if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
      outputAudioContextRef.current.close();
      outputAudioContextRef.current = null;
    }
    setConnectionState('disconnected');
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
        stopConversation();
    }
  }, [stopConversation]);

  return (
    <div className="max-w-3xl mx-auto">
        <h2 className="text-3xl font-bold text-cyan-500 mb-6">即時對話</h2>
        <div className="bg-white rounded-lg shadow-sm p-6 border border-slate-200">
            <div className="flex justify-center mb-6">
                {connectionState !== 'connected' ? (
                    <button onClick={startConversation} disabled={connectionState === 'connecting'} className="flex items-center space-x-2 bg-green-600 hover:bg-green-700 text-white font-bold py-3 px-6 rounded-full transition-colors disabled:bg-slate-300">
                        <MicOnIcon/>
                        <span>{connectionState === 'connecting' ? '連線中...' : '開始對話'}</span>
                    </button>
                ) : (
                    <button onClick={stopConversation} className="flex items-center space-x-2 bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-6 rounded-full transition-colors">
                        <StopIcon/>
                        <span>結束對話</span>
                    </button>
                )}
            </div>
            <div className="h-80 bg-slate-100 rounded-lg p-4 overflow-y-auto space-y-4">
                {transcripts.length === 0 && <p className="text-slate-500 text-center">你的對話將會顯示在這裡...</p>}
                {transcripts.map((t, i) => (
                    <div key={i} className={`flex ${t.speaker === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`px-4 py-2 rounded-lg text-white ${t.speaker === 'user' ? 'bg-blue-600' : 'bg-slate-500'}`}>
                           {t.text}
                        </div>
                    </div>
                ))}
            </div>
             <div className="text-center mt-4 text-slate-500 text-sm">
                {connectionState === 'connected' && <div className="flex items-center justify-center space-x-2"><div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div><span>直播中</span></div>}
                {connectionState === 'connecting' && <p>正在請求麥風權限...</p>}
                {connectionState === 'error' && <p>連線錯誤，請再試一次。</p>}
            </div>
        </div>
    </div>
  );
};

export default LiveAgent;