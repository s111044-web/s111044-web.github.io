import React, { useState } from 'react';
import { DiaryEntry, Emotion } from '../types';
import * as geminiService from '../services/geminiService';
import { SendIcon } from './Icons';

interface MoodDiaryProps {
  entries: DiaryEntry[];
  onAddEntry: (entry: DiaryEntry) => void;
}

const emotionStyles = {
    '正向': 'border-l-4 border-green-500',
    '負向': 'border-l-4 border-red-500',
    '中性': 'border-l-4 border-slate-400',
};

type Mood = '🤩' | '😊' | '😐' | '😢' | '😠';

const moods: Mood[] = ['🤩', '😊', '😐', '😢', '😠'];

const MoodDiary: React.FC<MoodDiaryProps> = ({ entries, onAddEntry }) => {
  const [newEntryContent, setNewEntryContent] = useState('');
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmitEntry = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEntryContent.trim() || isLoading) return;

    setIsLoading(true);
    const sentiment = await geminiService.analyzeSentiment(newEntryContent);
    setIsLoading(false);

    const newEntry: DiaryEntry = {
      id: new Date().toISOString(),
      content: newEntryContent,
      timestamp: new Date().toISOString(),
      emotion: sentiment,
      mood: selectedMood ?? undefined,
    };

    onAddEntry(newEntry);
    setNewEntryContent('');
    setSelectedMood(null);
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-3xl font-bold text-cyan-500 mb-6">心情日記</h2>
      <p className="text-slate-600 mb-6">這是你的私人空間。自由地寫下你的想法和感受。</p>
      
      <form onSubmit={handleSubmitEntry} className="mb-8">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
          <div className="flex justify-center space-x-4 mb-4">
              {moods.map(mood => (
                  <button 
                      key={mood}
                      type="button"
                      onClick={() => setSelectedMood(mood)}
                      className={`text-3xl p-2 rounded-full transition-transform duration-200 transform hover:scale-125 ${selectedMood === mood ? 'bg-cyan-100 ring-2 ring-cyan-400' : ''}`}
                  >
                      {mood}
                  </button>
              ))}
          </div>
          <div className="flex items-start space-x-4">
            <textarea
              value={newEntryContent}
              onChange={(e) => setNewEntryContent(e.target.value)}
              placeholder="今天感覺如何？"
              className="flex-1 bg-transparent focus:outline-none resize-none text-lg placeholder-slate-400 text-slate-800"
              rows={4}
              disabled={isLoading}
            />
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:cursor-not-allowed text-white rounded-full p-3 transition-all duration-200 self-end"
              disabled={isLoading || !newEntryContent.trim()}
            >
              {isLoading ? (
                <div className="w-6 h-6 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
              ) : <SendIcon />}
            </button>
          </div>
        </div>
      </form>
      
      <div className="space-y-4">
        {entries.map(entry => (
          <div key={entry.id} className={`relative bg-white rounded-lg p-4 shadow-sm border border-slate-200 ${emotionStyles[entry.emotion]}`}>
            {entry.mood && <div className="absolute top-3 right-3 text-2xl bg-slate-100 rounded-full p-1">{entry.mood}</div>}
            <p className="text-sm text-slate-500 mb-2">{new Date(entry.timestamp).toLocaleString()}</p>
            <p className="text-slate-700 whitespace-pre-wrap">{entry.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MoodDiary;