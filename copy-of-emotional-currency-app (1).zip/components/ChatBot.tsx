import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import * as geminiService from '../services/geminiService';
import { SendIcon, UserIcon, BotIcon } from './Icons';

const ChatBot: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [useSearch, setUseSearch] = useState(false);
    const [useThinking, setUseThinking] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;

        const userMessage: ChatMessage = { role: 'user', parts: [{ text: input }] };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            const response = await geminiService.generateChatResponse(messages, input, useSearch, useThinking);
            const modelMessage: ChatMessage = {
                role: 'model',
                parts: [{ text: response.text }],
                groundingChunks: response.candidates?.[0]?.groundingMetadata?.groundingChunks
            };
            setMessages(prev => [...prev, modelMessage]);
        } catch (error) {
            console.error("Error fetching chat response:", error);
            const errorMessage: ChatMessage = { role: 'model', parts: [{ text: "抱歉，我遇到了一個錯誤，請再試一次。" }] };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="flex flex-col h-[calc(100vh-8rem)] max-w-4xl mx-auto bg-white rounded-lg shadow-md border border-slate-200">
            <div className="p-4 border-b border-slate-200">
                <h2 className="text-2xl font-bold text-cyan-500">Gemini 聊天室</h2>
                <div className="flex items-center space-x-4 mt-2">
                    <label className="flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" checked={useSearch} onChange={() => setUseSearch(!useSearch)} className="form-checkbox h-5 w-5 text-blue-600 bg-slate-100 border-slate-300 rounded focus:ring-blue-500" />
                        <span className="text-slate-600">網路搜尋</span>
                    </label>
                    <label className="flex items-center space-x-2 cursor-pointer">
                        <input type="checkbox" checked={useThinking} onChange={() => setUseThinking(!useThinking)} className="form-checkbox h-5 w-5 text-purple-600 bg-slate-100 border-slate-300 rounded focus:ring-purple-500" />
                        <span className="text-slate-600">思考模式</span>
                    </label>
                </div>
            </div>
            <div className="flex-1 p-6 overflow-y-auto space-y-6 bg-slate-50">
                {messages.map((msg, index) => (
                    <div key={index} className={`flex items-start gap-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        {msg.role === 'model' && <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center"><BotIcon /></div>}
                        <div className={`max-w-lg rounded-xl px-5 py-3 shadow-sm ${msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-800'}`}>
                            <p className="whitespace-pre-wrap">{msg.parts[0].text}</p>
                            {msg.groundingChunks && msg.groundingChunks.length > 0 && (
                                <div className="mt-3 border-t border-slate-200 pt-2">
                                    <h4 className="text-xs font-semibold text-slate-500 mb-1">資料來源：</h4>
                                    <ul className="text-xs space-y-1">
                                        {msg.groundingChunks.map((chunk, i) => (
                                            chunk.web && <li key={i}><a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline truncate block">{chunk.web.title || chunk.web.uri}</a></li>
                                        ))}
                                    </ul>
                                </div>
                            )}
                        </div>
                        {msg.role === 'user' && <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center"><UserIcon /></div>}
                    </div>
                ))}
                {isLoading && (
                     <div className="flex items-start gap-4 justify-start">
                        <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center"><BotIcon /></div>
                        <div className="max-w-lg rounded-xl px-5 py-3 shadow-sm bg-slate-100 flex items-center space-x-2">
                           <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
                           <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                           <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <form onSubmit={handleSend} className="p-4 border-t border-slate-200 flex items-center space-x-4">
                <input
                    type="text"
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    placeholder="問 Gemini 任何問題..."
                    className="flex-1 bg-slate-100 rounded-full py-3 px-5 focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg"
                />
                <button type="submit" disabled={isLoading} className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-full p-3 transition-colors">
                    <SendIcon />
                </button>
            </form>
        </div>
    );
};

export default ChatBot;