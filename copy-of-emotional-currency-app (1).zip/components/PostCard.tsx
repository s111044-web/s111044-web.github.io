import React, { useState, useMemo, useRef, useEffect } from 'react';
import { Post, Comment, Emotion, User, Like, Reaction } from '../types';
import { CurrencyIcon, SendIcon, BotIcon, SmileyFaceIcon } from './Icons';
import * as geminiService from '../services/geminiService';

interface PostCardProps {
  post: Post;
  onAddTransaction: (reason: string, points: number) => void;
  currentUser: User;
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, comment: Comment) => void;
  onAddReaction: (postId: string, commentId: string, emoji: string) => void;
}

const GEMINI_BOT_USER: User = { 
    id: 'bot_gemini', 
    name: 'Gemini 小助手', 
    avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=Gemini` 
};

const emotionStyles = {
    '正向': 'border-l-4 border-green-500',
    '負向': 'border-l-4 border-red-500',
    '中性': 'border-l-4 border-slate-400',
};

const availableReactions = ['👍', '❤️', '😂', '😮', '😢', '😠', '🎉', '🙏', '🔥', '🤔', '💯', '🤯'];

const generateLikeText = (likes: Like[], currentUser: User): string => {
    const likeCount = likes.length;
    const isLikedByMe = likes.some(like => like.id === currentUser.id);
    
    if (likeCount === 0) return '';
    if (likeCount === 1 && isLikedByMe) return '你按了讚';
    if (likeCount === 1) return `${likes[0].name} 按了讚`;
    if (isLikedByMe) {
        if (likeCount === 2) {
             const otherLiker = likes.find(like => like.id !== currentUser.id);
             return `你和 ${otherLiker?.name || '1 人'} 按了讚`;
        }
        return `你和其他 ${likeCount - 1} 人按了讚`;
    }
    
    const otherLikers = likes.filter(like => like.id !== currentUser.id);
    if (otherLikers.length > 1) {
        return `${otherLikers[0].name} 和其他 ${otherLikers.length - 1} 人按了讚`;
    }
    return `${likes.map(l => l.name).join(' 和 ')} 按了讚`;
}

const PostCard: React.FC<PostCardProps> = ({ post, onAddTransaction, currentUser, onToggleLike, onAddComment, onAddReaction }) => {
  const [newComment, setNewComment] = useState('');
  const [isCommenting, setIsCommenting] = useState(false);
  const [isCommentLoading, setIsCommentLoading] = useState(false);
  const [isBotReplying, setIsBotReplying] = useState(false);
  const [activePickerCommentId, setActivePickerCommentId] = useState<string | null>(null);

  const isMyPost = post.author.id === currentUser.id;
  const isLikedByMe = post.likes.some(like => like.id === currentUser.id);
  const pickerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) {
        setActivePickerCommentId(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [pickerRef]);

  const handleLike = () => {
    onToggleLike(post.id);
    if(isMyPost && !isLikedByMe) {
        onAddTransaction(`貼文被按讚`, 1);
    }
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || isCommentLoading || isBotReplying) return;

    setIsCommentLoading(true);
    const userCommentContent = newComment;
    const sentiment = await geminiService.analyzeSentiment(userCommentContent);
    
    const userComment: Comment = {
      id: new Date().toISOString(),
      author: currentUser,
      content: userCommentContent,
      emotion: sentiment,
    };
    
    onAddComment(post.id, userComment);
    setNewComment('');
    setIsCommentLoading(false);

    if (isMyPost) {
        const points = sentiment === '正向' ? 2 : sentiment === '負向' ? -3 : 0;
        if (points !== 0) {
            onAddTransaction(`收到"${sentiment}"留言`, points);
        }
    } else {
        if (sentiment === '負向') {
            onAddTransaction('在他人貼文留下負向留言', -3);
        }
    }

    setIsBotReplying(true);
    try {
        const botReplyText = await geminiService.generateCommentResponse(post.content, userCommentContent);
        if (botReplyText) {
            const botSentiment = await geminiService.analyzeSentiment(botReplyText);
            const botComment: Comment = {
                id: new Date().toISOString() + '-bot',
                author: GEMINI_BOT_USER,
                content: botReplyText,
                emotion: botSentiment,
            };
            onAddComment(post.id, botComment);
        }
    } catch (error) {
        console.error("Bot failed to reply:", error);
    } finally {
        setIsBotReplying(false);
    }
  }
  
  const handleReaction = (commentId: string, emoji: string) => {
      onAddReaction(post.id, commentId, emoji);
      setActivePickerCommentId(null);
  }

  const groupedReactions = (reactions: Reaction[]) => {
      return reactions.reduce((acc, reaction) => {
          acc[reaction.emoji] = (acc[reaction.emoji] || 0) + 1;
          return acc;
      }, {} as Record<string, number>);
  }

  return (
    <div className={`bg-white rounded-lg p-4 shadow-sm border border-slate-200 ${emotionStyles[post.emotion]}`}>
      <div className="flex items-center mb-3">
        <img src={post.author.avatar} alt={post.author.name} className="w-10 h-10 rounded-full mr-3" />
        <div className="flex-1">
          <p className="font-semibold text-slate-800">{post.author.name}</p>
          <p className="text-xs text-slate-500">{new Date(post.timestamp).toLocaleString()}</p>
        </div>
        {isMyPost && typeof post.currency === 'number' && (
             <div className="flex items-center bg-slate-100 rounded-full px-2 py-0.5 text-xs border border-slate-200">
                <CurrencyIcon className="h-4 w-4 text-yellow-500" />
                <span className="ml-1 font-bold text-yellow-500">{post.currency}</span>
            </div>
        )}
      </div>
      <p className="text-slate-700 whitespace-pre-wrap mb-4">{post.content}</p>

      {post.likes.length > 0 && (
          <div className="text-sm text-slate-500 font-medium pb-2">
              {generateLikeText(post.likes, currentUser)}
          </div>
      )}

      <div className="flex items-center space-x-4 text-slate-500 border-t border-b border-slate-200 py-2">
          <button onClick={handleLike} className="flex items-center space-x-1 hover:text-red-500 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className={`h-5 w-5 transition-colors ${isLikedByMe ? 'text-red-500' : 'text-slate-400'}`} viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M3.172 5.172a4 4 0 015.656 0L10 6.343l1.172-1.171a4 4 0 115.656 5.656L10 17.657l-6.828-6.829a4 4 0 010-5.656z" clipRule="evenodd" /></svg>
            <span>讚</span>
          </button>
          <button onClick={() => setIsCommenting(!isCommenting)} className="flex items-center space-x-1 hover:text-cyan-500 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M18 5v8a2 2 0 01-2 2h-5l-5 4v-4H4a2 2 0 01-2-2V5a2 2 0 012-2h12a2 2 0 012 2zM7 8H5v2h2V8zm2 0h2v2H9V8zm6 0h-2v2h2V8z" clipRule="evenodd" /></svg>
            <span>{post.comments.length} 則留言</span>
          </button>
      </div>

      {isCommenting && (
          <div className="mt-4">
              <div className="space-y-4">
                  {post.comments.map(c => {
                      const isBot = c.author.id === 'bot_gemini';
                      const reactions = c.reactions || [];
                      const aggregated = groupedReactions(reactions);
                      const myReaction = reactions.find(r => r.user.id === currentUser.id);

                      return (
                          <div key={c.id} className="flex items-start space-x-2 text-sm">
                              {isBot ? (
                                <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center mt-1">
                                    <BotIcon className="h-5 w-5 text-white"/>
                                </div>
                              ) : (
                                <img src={c.author.avatar} alt={c.author.name} className="w-8 h-8 rounded-full mt-1"/>
                              )}
                              <div className="flex-1">
                                <div className={`relative group rounded-lg px-3 py-1.5 ${isBot ? 'bg-slate-200' : 'bg-slate-100'}`}>
                                    <div className="flex justify-between items-baseline">
                                        <p className={`font-semibold ${isBot ? 'text-cyan-600' : 'text-slate-700'}`}>{c.author.name}</p>
                                        <span className={`text-xs font-bold ${emotionStyles[c.emotion]}`.replace('border-l-4', 'text-').replace('-500', '-600').replace('-400', '-500')}>{c.emotion}</span>
                                    </div>
                                    <p className="text-slate-800 whitespace-pre-wrap">{c.content}</p>

                                    <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button onClick={() => setActivePickerCommentId(c.id === activePickerCommentId ? null : c.id)} className="p-1 rounded-full hover:bg-slate-200">
                                           <SmileyFaceIcon className="w-4 h-4 text-slate-500" />
                                        </button>
                                    </div>

                                    {activePickerCommentId === c.id && (
                                        <div ref={pickerRef} className="absolute z-10 -top-10 right-0 bg-white shadow-lg rounded-full p-1 flex space-x-1 border border-slate-200">
                                            {availableReactions.map(emoji => (
                                                <button key={emoji} onClick={() => handleReaction(c.id, emoji)} className={`p-1 rounded-full hover:bg-slate-200 transition-transform transform hover:scale-125 ${myReaction?.emoji === emoji ? 'bg-blue-100' : ''}`}>
                                                    <span className="text-lg">{emoji}</span>
                                                </button>
                                            ))}
                                        </div>
                                    )}
                                </div>
                                {reactions.length > 0 && (
                                     <div className="flex flex-wrap gap-2 mt-1 px-2">
                                         {Object.entries(aggregated).map(([emoji, count]) => (
                                             <div key={emoji} className="flex items-center bg-blue-100 text-blue-600 rounded-full px-2 py-0.5 text-xs">
                                                 <span>{emoji}</span>
                                                 <span className="ml-1 font-semibold">{count}</span>
                                             </div>
                                         ))}
                                     </div>
                                 )}
                              </div>
                          </div>
                      );
                  })}
                  {isBotReplying && (
                       <div className="flex items-start space-x-2 text-sm">
                            <div className="w-8 h-8 flex-shrink-0 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center mt-1">
                                <BotIcon className="h-5 w-5 text-white"/>
                            </div>
                            <div className="flex-1 rounded-lg px-3 py-1.5 bg-slate-200 flex items-center space-x-1.5 mt-1">
                                <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce"></div>
                                <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
                                <div className="w-1.5 h-1.5 bg-slate-500 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
                            </div>
                        </div>
                  )}
              </div>
              <form onSubmit={handleAddComment} className="flex items-center space-x-2 pt-3 mt-3 border-t border-slate-200">
                  <img src={currentUser.avatar} alt="Your Avatar" className="w-8 h-8 rounded-full"/>
                  <input
                    type="text"
                    value={newComment}
                    onChange={e => setNewComment(e.target.value)}
                    placeholder="新增留言..."
                    className="flex-1 bg-slate-100 rounded-full py-2 px-4 focus:outline-none focus:ring-1 focus:ring-blue-500 text-sm"
                    disabled={isCommentLoading || isBotReplying}
                  />
                  <button type="submit" disabled={isCommentLoading || isBotReplying || !newComment.trim()} className="text-blue-500 disabled:text-slate-400">
                    {isCommentLoading ? <div className="w-5 h-5 border-2 border-t-transparent border-slate-600 rounded-full animate-spin"></div> : <SendIcon/>}
                  </button>
              </form>
          </div>
      )}
    </div>
  );
};

export default PostCard;