import React, { useEffect } from 'react';
import { Achievement } from '../types';
import { CloseIcon, BronzeBadgeIcon, SilverBadgeIcon, GoldBadgeIcon, PlatinumBadgeIcon, DiamondBadgeIcon } from './Icons';

interface AchievementUnlockedModalProps {
  achievement: Achievement;
  onClose: () => void;
}

const badgeMap: Record<Achievement['level'], React.FC<{ className?: string }>> = {
  BRONZE: BronzeBadgeIcon,
  SILVER: SilverBadgeIcon,
  GOLD: GoldBadgeIcon,
  PLATINUM: PlatinumBadgeIcon,
  DIAMOND: DiamondBadgeIcon,
};

const achievementColors: Record<Achievement['level'], string> = {
    BRONZE: 'from-amber-100 to-white/0',
    SILVER: 'from-slate-200 to-white/0',
    GOLD: 'from-yellow-100 to-white/0',
    PLATINUM: 'from-cyan-100 to-white/0',
    DIAMOND: 'from-cyan-200 to-white/0',
}

const AchievementUnlockedModal: React.FC<AchievementUnlockedModalProps> = ({ achievement, onClose }) => {
    
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 5000); // Auto close after 5 seconds
    return () => clearTimeout(timer);
  }, [onClose]);

  const BadgeIcon = badgeMap[achievement.level];

  return (
    <div 
      className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div 
        className={`bg-white/95 relative rounded-2xl shadow-2xl w-full max-w-md border border-slate-200 transform animate-scale-up overflow-hidden`}
        onClick={e => e.stopPropagation()}
      >
        <div className={`absolute inset-x-0 top-0 h-48 bg-gradient-to-b ${achievementColors[achievement.level]}`}></div>
        <div className="p-8 text-center relative">
            <button onClick={onClose} className="absolute top-4 right-4 text-slate-400 hover:text-slate-800 transition-colors z-10">
                <CloseIcon className="w-5 h-5" />
            </button>

          <div className="relative inline-block animate-float">
            <BadgeIcon className="w-40 h-40" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/5 to-transparent rounded-full"></div>
          </div>
          
          <h2 className="text-sm font-bold tracking-widest text-cyan-500 uppercase mt-4">成就解鎖！</h2>
          <p className="text-4xl font-extrabold text-slate-800 mt-2 mb-4 drop-shadow-sm">
            {achievement.name}
          </p>

          <p className="text-slate-600 text-lg">
            恭喜！你已達到 <strong className="font-bold text-yellow-500">{achievement.minCurrency}</strong> 點情緒貨幣！
          </p>
        </div>
      </div>
       <style>{`
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes scale-up {
            from { transform: scale(0.9) translateY(20px); opacity: 0; }
            to { transform: scale(1) translateY(0); opacity: 1; }
        }
         @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
        }
        .animate-scale-up {
            animation: scale-up 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards;
        }
        .animate-float {
            animation: float 3s ease-in-out infinite;
        }
       `}</style>
    </div>
  );
};

export default AchievementUnlockedModal;