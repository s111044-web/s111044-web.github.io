import React from 'react';
import { WarningIcon } from './Icons';

interface ZeroCurrencyWarningModalProps {
  onClose: () => void;
}

const ZeroCurrencyWarningModal: React.FC<ZeroCurrencyWarningModalProps> = ({ onClose }) => {
  return (
    <div 
      className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-xl shadow-2xl w-full max-w-lg border-2 border-yellow-400 transform animate-scale-up"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-8 text-center">
          <div className="mx-auto flex items-center justify-center h-24 w-24 rounded-full bg-yellow-100 mb-6">
            <WarningIcon className="h-16 w-16 text-yellow-500" />
          </div>
          
          <h2 className="text-3xl font-extrabold text-yellow-500 mb-4">情緒貨幣警示</h2>
          
          <p className="text-slate-700 text-lg mb-6">
            你的情緒貨幣已歸零。這是一個提醒，請花點時間關心自己的感受。
          </p>

          <p className="text-slate-500 mb-8">
            試著寫一篇正向的日記，或在社群動態上分享一件美好的事來為自己充電吧！
          </p>

          <button 
            onClick={onClose} 
            className="w-full bg-yellow-400 hover:bg-yellow-500 text-yellow-900 font-bold py-3 px-6 rounded-lg transition-colors duration-300 text-lg focus:outline-none focus:ring-4 focus:ring-yellow-500/50"
          >
            我知道了
          </button>
        </div>
      </div>
       <style>{`
        @keyframes fade-in {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes scale-up {
            from { transform: scale(0.9); opacity: 0; }
            to { transform: scale(1); opacity: 1; }
        }
        .animate-fade-in {
            animation: fade-in 0.3s ease-out forwards;
        }
        .animate-scale-up {
            animation: scale-up 0.3s ease-out forwards;
        }
       `}</style>
    </div>
  );
};

export default ZeroCurrencyWarningModal;