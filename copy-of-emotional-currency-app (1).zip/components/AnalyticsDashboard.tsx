import React, { useMemo } from 'react';
import { Post, DiaryEntry, Transaction } from '../types';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar } from 'recharts';

interface AnalyticsDashboardProps {
  posts: Post[];
  diaryEntries: DiaryEntry[];
  transactions: Transaction[];
}

const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ posts, diaryEntries, transactions }) => {
  const combinedData = useMemo(() => {
    const allEntries = [
      ...posts.map(p => ({ timestamp: p.timestamp, emotion: p.emotion, type: 'post' })),
      ...diaryEntries.map(d => ({ timestamp: d.timestamp, emotion: d.emotion, type: 'diary' })),
    ].sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());

    const groupedByDay: { [key: string]: { date: string; '正向': number; '負向': number; '中性': number } } = {};

    allEntries.forEach(entry => {
      const date = new Date(entry.timestamp).toLocaleDateString();
      if (!groupedByDay[date]) {
        groupedByDay[date] = { date, '正向': 0, '負向': 0, '中性': 0 };
      }
      groupedByDay[date][entry.emotion]++;
    });

    return Object.values(groupedByDay);
  }, [posts, diaryEntries]);

  const emotionTotals = useMemo(() => {
      const totals = { '正向': 0, '負向': 0, '中性': 0 };
      combinedData.forEach(day => {
          totals['正向'] += day['正向'];
          totals['負向'] += day['負向'];
          totals['中性'] += day['中性'];
      });
      return [
          { name: '正向', count: totals['正向'], fill: '#22c55e'},
          { name: '負向', count: totals['負向'], fill: '#ef4444' },
          { name: '中性', count: totals['中性'], fill: '#64748b' }
      ];
  }, [combinedData]);

  if (posts.length === 0 && diaryEntries.length === 0) {
    return (
        <div className="text-center">
             <h2 className="text-3xl font-bold text-cyan-500 mb-6">數據分析</h2>
            <p className="text-slate-600">資料還不夠。先去建立一些貼文或日記吧！</p>
        </div>
    );
  }

  return (
    <div className="space-y-12">
      <h2 className="text-3xl font-bold text-cyan-500">數據分析</h2>
      
      <div>
        <h3 className="text-xl font-semibold text-slate-700 mb-4">積分紀錄</h3>
        <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 max-h-96 overflow-y-auto">
            {transactions.length > 0 ? (
                <ul className="divide-y divide-slate-200">
                    {transactions.map(t => (
                        <li key={t.id} className="py-3 flex justify-between items-center">
                            <div>
                               <p className="font-medium text-slate-800">{t.reason}</p>
                               <p className="text-sm text-slate-500">{new Date(t.timestamp).toLocaleString()}</p>
                            </div>
                            <span className={`font-bold text-lg ${t.points > 0 ? 'text-green-500' : 'text-red-500'}`}>
                                {t.points > 0 ? `+${t.points}` : t.points}
                            </span>
                        </li>
                    ))}
                </ul>
            ) : (
                <p className="text-slate-500 text-center py-4">尚未有任何積分紀錄。</p>
            )}
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-slate-700 mb-4">情緒時間趨勢</h3>
        <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 h-96">
            <ResponsiveContainer width="100%" height="100%">
            <LineChart data={combinedData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis dataKey="date" stroke="#64748b" />
                <YAxis stroke="#64748b" allowDecimals={false} />
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0' }} />
                <Legend />
                <Line type="monotone" dataKey="正向" stroke="#22c55e" strokeWidth={2} activeDot={{ r: 8 }} />
                <Line type="monotone" dataKey="負向" stroke="#ef4444" strokeWidth={2} />
                <Line type="monotone" dataKey="中性" stroke="#64748b" strokeWidth={2} />
            </LineChart>
            </ResponsiveContainer>
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-slate-700 mb-4">整體情緒分佈</h3>
        <div className="bg-white p-4 rounded-lg shadow-sm border border-slate-200 h-96">
            <ResponsiveContainer width="100%" height="100%">
            <BarChart data={emotionTotals} layout="vertical" margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis type="number" stroke="#64748b" allowDecimals={false}/>
                <YAxis type="category" dataKey="name" stroke="#64748b" />
                <Tooltip contentStyle={{ backgroundColor: '#ffffff', border: '1px solid #e2e8f0' }} cursor={{fill: 'rgba(203, 213, 225, 0.5)'}}/>
                <Bar dataKey="count" barSize={30} />
            </BarChart>
            </ResponsiveContainer>
        </div>
      </div>

    </div>
  );
};

export default AnalyticsDashboard;