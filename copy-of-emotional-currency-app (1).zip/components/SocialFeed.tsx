
import React, { useState } from 'react';
import { Post, User, Emotion, Comment } from '../types';
import PostCard from './PostCard';
import * as geminiService from '../services/geminiService';
import { SendIcon, CurrencyIcon } from './Icons';

interface SocialFeedProps {
  posts: Post[];
  onAddPost: (content: string, emotion: Emotion) => void;
  onAddTransaction: (reason: string, points: number) => void;
  emotionalCurrency: number;
  currentUser: User;
  onToggleLike: (postId: string) => void;
  onAddComment: (postId: string, comment: Comment) => void;
  onAddReaction: (postId: string, commentId: string, emoji: string) => void;
}

const SocialFeed: React.FC<SocialFeedProps> = ({ posts, onAddPost, onAddTransaction, emotionalCurrency, currentUser, onToggleLike, onAddComment, onAddReaction }) => {
  const [newPostContent, setNewPostContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmitPost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPostContent.trim() || isLoading) return;

    setIsLoading(true);
    const sentiment = await geminiService.analyzeSentiment(newPostContent);
    setIsLoading(false);

    onAddPost(newPostContent, sentiment);
    setNewPostContent('');
  };

  return (
    <div className="max-w-3xl mx-auto">
      <h2 className="text-3xl font-bold text-cyan-500 mb-6">社群動態</h2>
      
      <form onSubmit={handleSubmitPost} className="mb-8">
        <div className="bg-white rounded-lg p-4 shadow-sm border border-slate-200">
           <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-slate-500">分享你的想法...</span>
                <div className="flex items-center bg-slate-100 rounded-full px-3 py-1 text-sm border border-slate-200">
                    <CurrencyIcon className="h-4 w-4 text-yellow-500" />
                    <span className="ml-1.5 font-bold text-yellow-500">{emotionalCurrency}</span>
                </div>
            </div>
          <div className="flex items-start space-x-4">
            <img src={currentUser.avatar} alt="Your avatar" className="w-10 h-10 rounded-full"/>
            <textarea
              value={newPostContent}
              onChange={(e) => setNewPostContent(e.target.value)}
              placeholder="今天過得如何？"
              className="flex-1 bg-transparent focus:outline-none resize-none text-lg placeholder-slate-400 text-slate-800"
              rows={3}
              disabled={isLoading}
            />
            <button
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 disabled:cursor-not-allowed text-white rounded-full p-3 transition-all duration-200 self-end"
              disabled={isLoading || !newPostContent.trim()}
            >
              {isLoading ? (
                <div className="w-6 h-6 border-2 border-t-transparent border-white rounded-full animate-spin"></div>
              ) : <SendIcon />}
            </button>
          </div>
        </div>
      </form>
      
      <div className="space-y-4">
        {posts.map(post => (
          <PostCard 
            key={post.id} 
            post={post} 
            onAddTransaction={onAddTransaction} 
            currentUser={currentUser}
            onToggleLike={onToggleLike}
            onAddComment={onAddComment}
            onAddReaction={onAddReaction}
          />
        ))}
      </div>
    </div>
  );
};

export default SocialFeed;