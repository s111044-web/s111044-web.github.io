import { GoogleGenAI, GenerateContentResponse, Chat, LiveCallbacks, LiveSession, Type, Modality, Content } from "@google/genai";
import { ChatMessage, Emotion, FeedbackAnalysis } from '../types';

const getGenAIClient = () => {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
        throw new Error("API_KEY environment variable not set");
    }
    return new GoogleGenAI({ apiKey });
};

export const analyzeSentiment = async (text: string): Promise<Emotion> => {
  try {
    const ai = getGenAIClient();
    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            sentiment: {
                type: Type.STRING,
                description: "文字的情緒。可以是 '正向', '負向', 或 '中性'。",
            },
        },
        required: ['sentiment'],
    };

    const response = await ai.models.generateContent({
        model: 'gemini-flash-lite-latest',
        contents: [{ role: 'user', parts: [{text: `分析這段文字的情緒: "${text}"。將其分類為'正向'、'負向'或'中性'。`}]}],
        config: {
            responseMimeType: 'application/json',
            responseSchema: responseSchema,
        }
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);

    if (['正向', '負向', '中性'].includes(result.sentiment)) {
        return result.sentiment;
    }
    return '中性';
  } catch (error) {
    console.error("Error analyzing sentiment:", error);
    return '中性';
  }
};

export const analyzeFeedback = async (rating: number, comment: string): Promise<FeedbackAnalysis> => {
    const ai = getGenAIClient();
    const prompt = `
        分析以下應用程式回饋。
        評分: ${rating}/5
        評論: "${comment}"

        請提供以下 JSON 格式的分析:
        1.  summary: 一句話總結這條回饋的主要觀點。
        2.  category: 將此回饋分類為 '錯誤回報', '功能建議', '正面評價', '負面評價', 'UI/UX 建議' 或 '其他'。
        3.  sentiment: 將評論的情緒分類為 '正向', '負向', 或 '中性'。
    `;

    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            summary: { type: Type.STRING },
            category: { type: Type.STRING },
            sentiment: { type: Type.STRING },
        },
        required: ['summary', 'category', 'sentiment'],
    };

    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        config: {
            responseMimeType: 'application/json',
            responseSchema: responseSchema,
        }
    });

    const jsonText = response.text.trim();
    const result = JSON.parse(jsonText);
    
    // Ensure sentiment is one of the valid Emotion types
    if (!['正向', '負向', '中性'].includes(result.sentiment)) {
        result.sentiment = '中性';
    }

    return result as FeedbackAnalysis;
};

export const generateCommentResponse = async (postContent: string, userComment: string): Promise<string> => {
    try {
        const ai = getGenAIClient();
        const prompt = `你是一個線上社群中友善且富同理心的成員，名叫「Gemini 小助手」。
        你的目標是促進正向互動。
        有一篇貼文內容是：「${postContent}」
        一位使用者剛剛對這篇貼文留言：「${userComment}」
        
        請根據貼文和留言的內容，寫下一則簡短、有建設性且相關的回應。
        - 如果留言是正向的，可以表示同意或讚美。
        - 如果留言是負向的，試著提供支持或一個不同的觀點，但不要說教。
        - 保持友善和自然的語氣。
        - 你的回應應該在50個字以內。
        - 直接輸出你的回應，不要包含任何前言或署名。`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [{ role: 'user', parts: [{ text: prompt }] }],
            config: {
                temperature: 0.8,
            }
        });

        return response.text.trim();
    } catch (error) {
        console.error("Error generating comment response:", error);
        return ""; // Return empty string on error
    }
};


export const generateChatResponse = async (
    history: ChatMessage[], 
    newMessage: string,
    useSearch: boolean,
    useThinking: boolean
): Promise<GenerateContentResponse> => {
    const ai = getGenAIClient();
    const modelName = useThinking ? 'gemini-2.5-pro' : 'gemini-2.5-flash';
    
    const contents: Content[] = [
        ...history.map(msg => ({ role: msg.role, parts: msg.parts })),
        { role: 'user', parts: [{ text: newMessage }] }
    ];
    
    const config: any = {};
    if (useThinking) {
        config.thinkingConfig = { thinkingBudget: 32768 };
    }
    if (useSearch) {
        config.tools = [{ googleSearch: {} }];
    }

    const response = await ai.models.generateContent({
        model: modelName,
        contents: contents,
        ...(Object.keys(config).length > 0 && { config })
    });
    return response;
};

export const generateSpeech = async (prompt: string): Promise<string | null> => {
    try {
        const ai = getGenAIClient();
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: prompt }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                      prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return base64Audio || null;
    } catch (error) {
        console.error("Error generating speech:", error);
        return null;
    }
};

export const connectLive = async (callbacks: LiveCallbacks): Promise<LiveSession> => {
    const ai = getGenAIClient();
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: callbacks,
        config: {
            responseModalities: [Modality.AUDIO],
            outputAudioTranscription: {},
            inputAudioTranscription: {},
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
            },
            systemInstruction: '你是一位友善且樂於助人的情緒支援夥伴。請讓你的回覆簡潔並充滿支持。',
        },
    });
};