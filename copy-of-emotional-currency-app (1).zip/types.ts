export type Emotion = '正向' | '負向' | '中性';

export interface User {
  id: string;
  name: string;
  avatar: string;
}

export type Like = User;

export interface Reaction {
  emoji: string;
  user: User;
}

export interface Comment {
  id: string;
  author: User;
  content: string;
  emotion: Emotion;
  reactions?: Reaction[];
}

export interface Post {
  id: string;
  author: User;
  content: string;
  timestamp: string;
  emotion: Emotion;
  currency?: number;
  likes: Like[];
  comments: Comment[];
}

export type Mood = '🤩' | '😊' | '😐' | '😢' | '😠';

export interface DiaryEntry {
  id: string;
  content: string;
  timestamp: string;
  emotion: Emotion;
  mood?: Mood;
}

export interface Transaction {
  id: string;
  reason: string;
  points: number;
  timestamp: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
  groundingChunks?: any[];
}

export interface FeedbackAnalysis {
    summary: string;
    category: string;
    sentiment: Emotion;
}

export type AchievementLevel = 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM' | 'DIAMOND';

export interface Achievement {
  level: AchievementLevel;
  name: string;
  minCurrency: number;
}