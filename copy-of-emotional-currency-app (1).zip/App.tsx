
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Post, DiaryEntry, Transaction, Emotion, Achievement, AchievementLevel, User, Comment, Reaction } from './types';
import SocialFeed from './components/SocialFeed';
import MoodDiary from './components/MoodDiary';
import MoodRadio from './components/MoodRadio';
import ChatBot from './components/ChatBot';
import LiveAgent from './components/LiveAgent';
import AnalyticsDashboard from './components/AnalyticsDashboard';
import FeedbackModal from './components/FeedbackModal';
import ZeroCurrencyWarningModal from './components/ZeroCurrencyWarningModal';
import Avatar from './components/Avatar';
import AvatarSelectionModal from './components/AvatarSelectionModal';
import AchievementUnlockedModal from './components/AchievementUnlockedModal';
import { CurrencyIcon, FeedbackIcon } from './components/Icons';

type Tab = 'feed' | 'diary' | 'radio' | 'chat' | 'live' | 'analytics';

const ACHIEVEMENTS: readonly Achievement[] = [
    { level: 'DIAMOND', name: '鑽石之心', minCurrency: 100 },
    { level: 'PLATINUM', name: '鉑金耀星', minCurrency: 90 },
    { level: 'GOLD', name: '黃金守護者', minCurrency: 70 },
    { level: 'SILVER', name: '白銀支持者', minCurrency: 50 },
    { level: 'BRONZE', name: '青銅貢獻者', minCurrency: 30 },
] as const;

const BOT_USERS: User[] = [
    { id: 'user_jane', name: 'Jane Doe', avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Jane' },
    { id: 'user_john', name: 'John Smith', avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=John' },
    { id: 'user_alex', name: 'Alex Ray', avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Alex' },
    { id: 'user_sara', name: 'Sara Conner', avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Sara' },
    { id: 'user_mike', name: 'Mike Ross', avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=Mike' },
];

const App: React.FC = () => {
    const [activeTab, setActiveTab] = useState<Tab>('feed');
    const [currentUser, setCurrentUser] = useState<User>({
        id: 'user_you',
        name: 'You',
        avatar: 'https://api.dicebear.com/7.x/adventurer/svg?seed=You'
    });
    const [posts, setPosts] = useState<Post[]>([
        {
            id: '1',
            author: BOT_USERS[0],
            content: '在山頂看日出，感覺整個世界都安靜了下來。大自然真是太療癒了！☀️ #日出 #登山',
            timestamp: new Date(Date.now() - 86400000 * 2).toISOString(),
            emotion: '正向',
            likes: [BOT_USERS[1], BOT_USERS[3], BOT_USERS[4]],
            comments: [
                {
                    id: 'c1-1',
                    author: BOT_USERS[1],
                    content: '照片拍得太美了！',
                    emotion: '正向',
                    reactions: [{ emoji: '❤️', user: BOT_USERS[0] }, { emoji: '👍', user: BOT_USERS[3] }]
                },
                {
                    id: 'c1-2',
                    author: BOT_USERS[4],
                    content: '好想去！下次可以揪團嗎？',
                    emotion: '正向'
                }
            ]
        },
        {
            id: '2',
            author: BOT_USERS[2],
            content: '今天的專案報告壓力好大，感覺快被淹沒了... 大家都是怎麼舒壓的？',
            timestamp: new Date(Date.now() - 86400000).toISOString(),
            emotion: '負向',
            likes: [BOT_USERS[0]],
            comments: [
                {
                    id: 'c2-1',
                    author: BOT_USERS[0],
                    content: '拍拍，辛苦了。我通常會去運動一下，流流汗心情會好很多！',
                    emotion: '正向',
                    reactions: [{ emoji: '❤️', user: BOT_USERS[2] }]
                },
                {
                    id: 'c2-2',
                    author: BOT_USERS[3],
                    content: '聽點輕鬆的音樂或者冥想10分鐘，也很有用。',
                    emotion: '中性'
                }

            ]
        },
        {
            id: '3',
            author: BOT_USERS[3],
            content: '發現了一家超棒的巷弄咖啡廳，他們的肉桂捲是天堂等級的美味。',
            timestamp: new Date(Date.now() - 43200000).toISOString(),
            emotion: '正向',
            likes: [BOT_USERS[0], BOT_USERS[1], BOT_USERS[2], BOT_USERS[4]],
            comments: []
        },
        {
            id: '4',
            author: BOT_USERS[1],
            content: '花了一個下午整理房間，雖然累但看著整齊的空間，心情意外地平靜。',
            timestamp: new Date(Date.now() - 23200000).toISOString(),
            emotion: '中性',
            likes: [BOT_USERS[3]],
            comments: [
                 {
                    id: 'c4-1',
                    author: BOT_USERS[3],
                    content: '斷捨離的快樂！',
                    emotion: '正向',
                    reactions: [{ emoji: '👍', user: BOT_USERS[1] }]
                }
            ]
        },
    ]);
    const [diaryEntries, setDiaryEntries] = useState<DiaryEntry[]>([
        { id: 'd1', content: '今天學到了一個新的 React hook，很有成就感。', timestamp: new Date(Date.now() - 172800000).toISOString(), emotion: '正向' }
    ]);
    const [transactions, setTransactions] = useState<Transaction[]>([
        {id: 't1', reason: '發布貼文', points: 10, timestamp: new Date(Date.now() - 86400000).toISOString()},
        {id: 't2', reason: '撰寫日記', points: 5, timestamp: new Date(Date.now() - 172800000).toISOString()},
    ]);
    const [lastEmotion, setLastEmotion] = useState<Emotion>('中性');
    const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
    const [isWarningModalOpen, setIsWarningModalOpen] = useState(false);
    const [isAvatarModalOpen, setIsAvatarModalOpen] = useState(false);
    const [unlockedAchievements, setUnlockedAchievements] = useState<AchievementLevel[]>([]);
    const [newlyUnlocked, setNewlyUnlocked] = useState<Achievement | null>(null);

    const emotionalCurrency = useMemo(() => {
        return transactions.reduce((sum, transaction) => sum + transaction.points, 0);
    }, [transactions]);

    const prevCurrencyRef = useRef<number | undefined>(undefined);

    useEffect(() => {
        const prevCurrency = prevCurrencyRef.current;
        if (prevCurrency !== undefined && prevCurrency > 0 && emotionalCurrency <= 0) {
            setIsWarningModalOpen(true);
        }
        prevCurrencyRef.current = emotionalCurrency;

        const highestPossibleAchievement = ACHIEVEMENTS.find(ach => emotionalCurrency >= ach.minCurrency);
        if (highestPossibleAchievement && !unlockedAchievements.includes(highestPossibleAchievement.level)) {
            const allToUnlock = ACHIEVEMENTS.filter(ach => emotionalCurrency >= ach.minCurrency);
            setUnlockedAchievements(allToUnlock.map(a => a.level));
            setNewlyUnlocked(highestPossibleAchievement);
        }

    }, [emotionalCurrency, unlockedAchievements]);
    
    // Simulates other users' activity
    useEffect(() => {
        const botComments = ['這很有趣！', '說得好！', '我同意。', '感謝分享！'];
        const intervalId = setInterval(() => {
            setPosts(prevPosts => {
                if (prevPosts.length === 0) return prevPosts;
                const postIndex = Math.floor(Math.random() * prevPosts.length);
                const postToUpdate = prevPosts[postIndex];
                const randomBot = BOT_USERS[Math.floor(Math.random() * BOT_USERS.length)];

                let updatedPost: Post;
                if (Math.random() > 0.4) { // 60% chance to like
                    if (!postToUpdate.likes.some(like => like.id === randomBot.id)) {
                        updatedPost = { ...postToUpdate, likes: [...postToUpdate.likes, randomBot] };
                        return prevPosts.map((p, i) => i === postIndex ? updatedPost : p);
                    }
                } else { // 40% chance to comment
                    const newComment: Comment = {
                        id: new Date().toISOString(),
                        author: randomBot,
                        content: botComments[Math.floor(Math.random() * botComments.length)],
                        emotion: '中性'
                    };
                    updatedPost = { ...postToUpdate, comments: [...postToUpdate.comments, newComment] };
                    return prevPosts.map((p, i) => i === postIndex ? updatedPost : p);
                }
                return prevPosts;
            });
        }, 15000); 

        return () => clearInterval(intervalId);
    }, []);


    const highestAchievement = useMemo((): Achievement | null => {
        if (unlockedAchievements.length === 0) return null;
        return ACHIEVEMENTS.find(ach => unlockedAchievements.includes(ach.level)) || null;
    }, [unlockedAchievements]);
    
    const handleSelectAvatar = (avatarUrl: string) => {
        setCurrentUser(prev => ({...prev, avatar: avatarUrl }));
        setIsAvatarModalOpen(false);
    };

    const addTransaction = (reason: string, points: number) => {
        const newTransaction: Transaction = {
            id: new Date().toISOString(),
            reason,
            points,
            timestamp: new Date().toISOString(),
        };
        setTransactions(prev => [newTransaction, ...prev]);
    }
    
    const handleAddPost = (content: string, emotion: Emotion) => {
        const newPost: Post = {
            id: new Date().toISOString(),
            author: currentUser,
            content: content,
            timestamp: new Date().toISOString(),
            emotion: emotion,
            currency: emotionalCurrency,
            likes: [],
            comments: []
        };
        setPosts(prev => [newPost, ...prev]);
        setLastEmotion(emotion);
        const points = emotion === '正向' ? 10 : emotion === '負向' ? -10 : 0;
        if (points !== 0) {
            addTransaction('發布貼文', points);
        }
    };

    const handleAddEntry = (entry: DiaryEntry) => {
        setDiaryEntries(prev => [entry, ...prev]);
        setLastEmotion(entry.emotion);
        const points = entry.emotion === '正向' ? 10 : entry.emotion === '負向' ? -10 : 0;
         if (points !== 0) {
            addTransaction('撰寫日記', points);
        }
    };

    const handleToggleLike = (postId: string) => {
        setPosts(prevPosts => prevPosts.map(p => {
            if (p.id !== postId) return p;
            const existingLikeIndex = p.likes.findIndex(like => like.id === currentUser.id);
            const newLikes = existingLikeIndex >= 0
                ? p.likes.filter(like => like.id !== currentUser.id)
                : [...p.likes, currentUser];
            return { ...p, likes: newLikes };
        }));
    };

    const handleAddCommentToPost = (postId: string, comment: Comment) => {
        setPosts(prevPosts => prevPosts.map(p => {
            if (p.id !== postId) return p;
            return { ...p, comments: [...p.comments, comment] };
        }));
    };

    const handleAddReactionToComment = (postId: string, commentId: string, emoji: string) => {
        setPosts(posts => posts.map(p => {
            if (p.id !== postId) return p;

            return {
                ...p,
                comments: p.comments.map(c => {
                    if (c.id !== commentId) return c;

                    const existingReactions = c.reactions || [];
                    const myReactionIndex = existingReactions.findIndex(r => r.user.id === currentUser.id && r.emoji === emoji);

                    let newReactions: Reaction[];
                    if (myReactionIndex >= 0) {
                        // User is removing the same reaction
                        newReactions = existingReactions.filter((_, index) => index !== myReactionIndex);
                    } else {
                        // User is adding a new reaction. We'll allow multiple different reactions from the same user.
                        newReactions = [...existingReactions, { emoji, user: currentUser }];
                    }
                    return { ...c, reactions: newReactions };
                })
            };
        }));
    };

    const renderContent = () => {
        switch (activeTab) {
            case 'feed':
                return <SocialFeed 
                            posts={posts} 
                            onAddPost={handleAddPost} 
                            onAddTransaction={addTransaction} 
                            emotionalCurrency={emotionalCurrency} 
                            currentUser={currentUser}
                            onToggleLike={handleToggleLike}
                            onAddComment={handleAddCommentToPost}
                            onAddReaction={handleAddReactionToComment}
                        />;
            case 'diary':
                return <MoodDiary entries={diaryEntries} onAddEntry={handleAddEntry} />;
            case 'radio':
                return <MoodRadio lastEmotion={lastEmotion} />;
            case 'chat':
                return <ChatBot />;
            case 'live':
                return <LiveAgent />;
            case 'analytics':
                return <AnalyticsDashboard posts={posts} diaryEntries={diaryEntries} transactions={transactions} />;
            default:
                return null;
        }
    };
    
    const TabButton: React.FC<{ tab: Tab; label: string }> = ({ tab, label }) => (
        <button
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === tab 
                ? 'bg-cyan-500 text-white' 
                : 'text-slate-500 hover:bg-slate-200'
            }`}
        >
            {label}
        </button>
    );

    return (
        <div className="bg-slate-50 text-slate-800 min-h-screen font-sans">
            <header className="bg-white/80 backdrop-blur-sm sticky top-0 z-10 border-b border-slate-200">
                <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="flex items-center justify-between h-16">
                        <div className="flex items-center space-x-4">
                            <Avatar src={currentUser.avatar} emotion={lastEmotion} onClick={() => setIsAvatarModalOpen(true)} achievement={highestAchievement} />
                            <h1 className="text-xl font-bold text-cyan-500">情緒中心</h1>
                             <button onClick={() => setIsFeedbackModalOpen(true)} className="text-slate-500 hover:text-cyan-500 transition-colors" aria-label="Provide Feedback">
                                <FeedbackIcon />
                            </button>
                        </div>
                        <div className="flex items-center space-x-4">
                            <div className="flex items-center bg-slate-100 rounded-full px-3 py-1 border border-slate-200">
                                <CurrencyIcon className="h-5 w-5 text-yellow-500" />
                                <span className="ml-2 font-bold text-yellow-500 text-lg">{emotionalCurrency}</span>
                            </div>
                            <div className="hidden sm:flex space-x-2">
                               <TabButton tab="feed" label="社群動態" />
                               <TabButton tab="diary" label="心情日記" />
                               <TabButton tab="radio" label="心情電台" />
                               <TabButton tab="chat" label="聊天室" />
                               <TabButton tab="live" label="即時對話" />
                               <TabButton tab="analytics" label="數據分析" />
                            </div>
                        </div>
                    </div>
                </nav>
            </header>
            <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {renderContent()}
            </main>
            {isFeedbackModalOpen && <FeedbackModal onClose={() => setIsFeedbackModalOpen(false)} />}
            {isWarningModalOpen && <ZeroCurrencyWarningModal onClose={() => setIsWarningModalOpen(false)} />}
            {isAvatarModalOpen && <AvatarSelectionModal onClose={() => setIsAvatarModalOpen(false)} onSelect={handleSelectAvatar} />}
            {newlyUnlocked && <AchievementUnlockedModal achievement={newlyUnlocked} onClose={() => setNewlyUnlocked(null)} />}
        </div>
    );
};

export default App;
